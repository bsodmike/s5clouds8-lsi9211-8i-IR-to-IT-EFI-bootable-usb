************************************************************************************************************************
Package for P20 Firmware BIOS Upgrade on MSDOS & Windows
************************************************************************************************************************
LSI Host Bus Adapter(HBA) - LSI SAS 9211-8i

Package Contents- 

Readme first note      :  README_9211_8i_Package_P20_IR_IT_Firmware_BIOS_for_MSDOS_Windows.txt 

Installer(SAS2FLSH)    :  \sas2flash_dos_rel\sas2flsh                   Version no: 20.00.00.00     Release date: 18-SEP-14
Installer(SAS2FLASH)   :  \sas2flash_win_x86_rel\sas2flash              Version no: 20.00.00.00     Release date: 18-SEP-14
Installer(SAS2FLASH)   :  \sas2flash_win_x64_rel\sas2flash              Version no: 20.00.00.00     Release date: 18-SEP-14 
Installer(SAS2FLASH)   :  \sas2flash_win_ia64_rel\sas2flash             Version no: 20.00.00.00     Release date: 18-SEP-14

Reference Guide        :  SAS2Flash_ReferenceGuide.pdf                  Version no: 2.1             Release date: JUNE-11

Firmware               :  \firmware\HBA_9211_8i_IR\2118ir.bin           Version no: 20.00.07.00     Release date: 11-FEB-16

Firmware               :  \firmware\HBA_9211_8i_IT\2118it.bin           Version no: 20.00.07.00     Release date: 11-FEB-16

BIOS                   :  \sasbios_rel\mptsas2.rom                      Version no: 7.39.02.00      Release date: 03-AUG-15
Readme for BIOS        :  \sasbios_rel\mptbios.txt                      Version no: NA              Release date: NA


----------------------------------------------------------------------------------------------------------------------------

